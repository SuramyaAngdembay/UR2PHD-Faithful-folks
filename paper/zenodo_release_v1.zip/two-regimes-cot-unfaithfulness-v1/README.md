# Analysis code and results: Two Regimes of Chain-of-Thought Unfaithfulness

Suramya R. Angdembay, Dikshant Aryal, Nick Rahimi
The University of Southern Mississippi

Analysis code and per-experiment result files backing every quantitative claim in the
paper. Preprint: arXiv (v2 or later). **Please work from v2 or later**: v1 predates the
LLM-judge experiment, which showed a prompted judge retains signal in the regime where
metric-based signals are at chance, and the paper's headline claim was narrowed
accordingly ("Behavioral" -> "Metric-Based Detection Fails Where Models Are Wrong").
The label-semantics correction described below is present in *both* v1 and v2.

## Reproducing: read this first

**The benchmark's own documentation disagreed with its released data about label
semantics.** In the FaithCoT-Bench data the four-way codes pair as:

    ft1 faithful / ft2 unfaithful  on INCORRECT answers
    ft3 faithful / ft4 unfaithful  on CORRECT answers   (ft4 = post-hoc on correct)

The repository documentation stated this the other way around at the time of our
analysis (since corrected upstream). Any reproduction that inherits the documented
pairing rather than the data-side pairing will silently swap the two regimes and appear
to contradict our results. Verify against the raw data first:

    python scripts/label_crosstabs.py     # faithful_type x correctness from stored fields
    python scripts/validate_data.py       # per-domain parsed==label crosstabs
    python scripts/faithcot_reproduce.py  # reproduces the benchmark's own accuracy stats

These reproduce the crosstabulations in Appendix A and are the intended entry point for
an independent audit.

## Not included here

- `utils/faithfulness.py` **belongs to the FaithCoT-Bench release, not to this work.**
  Every pipeline in their repository imports it, but it is not distributed with their
  release. Our analyses therefore use their *stored* per-trace scores throughout. Our
  own reimplementation sanity check is in `scripts/` and is documented in the appendix
  (Pearson 0.711 / Spearman 0.822 against the stored scores on 30 recomputed traces).
- Raw trace data, activation caches, fitted probe weights and per-example predictions
  (several GB). These are being prepared and will be added as a subsequent version of
  this Zenodo record under the same concept DOI.

## Claims -> scripts map (main paper)
- S3 label semantics (crosstabs, census; Table 6 / App. A): scripts/label_crosstabs.py -> results/label_crosstabs.json
- S4 black-box audit + regime split (Tables 1-2, Fig. 3): scripts/audit_corrected.py -> results/audit_corrected.json
- S4 inversion on the benchmark's own released scores: scripts/faithcot_reproduce.py -> results/faithcot_reproduce.json
- S4 four-model NLI/DAG replication: scripts/rigorous_analysis.py -> results/regime_fullset_nlidag.json
- S6 regime probes (Table 3): scripts/ft34_probe.py, scripts/regime_transfers.py -> results/ft34_probe_*.json, results/regime_transfers_*.json
- S7 instructed construction, 7 models (Table 4): scripts/synth_generate.py, synth_extract.py, synth_analyze.py -> results/synth_*.json
- S7 hint testbed (generation, filtering, decodability, inversion): scripts/hint_generate.py (+build_logiqa.py for LogiQA) -> results/synth_*_hint*.json
- S7 transfer matrix (Table 5, Fig. 5): scripts/bridge3.py, bridge3_perm.py, hintL_bridge.py -> results/bridge3_*.json, results/hintL_bridge_*.json
- S7 question-only control: scripts/qonly_extract.py, qonly_transfer.py
- App. E robustness (template B, strict subset): scripts/strict_subset.py, flip_stability2.py
- App. G SAE negative: scripts/sae_transfers.py; steering: intervention_harness*.py
- App. H AUPRC + forest: scripts/appendix_extras.py -> results/appendix_extras.json
- Data integrity / external accuracy anchors: scripts/validate_data3.py -> results/validate3.json
- S4/S5 LLM-judge baseline (fifth family; full labeled set): scripts/judge_baseline.py -> results/judge_baseline.json
- S4/S5 regime-difference + paired oracle-vs-metric tests: scripts/regime_delta_tests.py -> results/regime_delta_tests.json
- S4/S5 judge same-sample comparisons, degradation test, own-trace exclusion: scripts/judge_extras.py -> results/judge_extras.json
- S8 judge-probe complementarity (metric-blind regime): scripts/judge_probe_comp.py -> results/judge_probe_comp.json
- Temper-search analyses (judge per-domain/composition, clustered bootstrap, length/NLI decomposition, text-transfer control): scripts/temper_patch.py, embed_transfer.py -> results/temper_patch.json, temper_local.json, embed_transfer.json
- Every headline number, recomputed from JSONs: scripts/paper_numbers.py

## Environment
Python 3.10+; numpy, scikit-learn, torch (GPU steps), transformers, matplotlib.
GPU steps ran on 2x RTX 3070 (8 GB) with 4-bit NF4 quantization; exact checkpoints in
paper Appendix (Table: Model checkpoints). CPU-only scripts are marked in their headers.
